export const SAMPLE_COMMENTS = [
  {
    id: 1,
    author: "techmaster",
    content: "This is really impressive! The attention to detail in the design is outstanding.",
    votes: 45,
    timeAgo: "2 hours ago",
    replies: [
      {
        id: 2,
        author: "designpro",
        content: "Agreed! The color scheme is particularly well thought out.",
        votes: 12,
        timeAgo: "1 hour ago",
        replies: []
      }
    ]
  },
  {
    id: 3,
    author: "webdev_pro",
    content: "Great implementation! Have you considered adding keyboard navigation?",
    votes: 23,
    timeAgo: "3 hours ago",
    replies: []
  }
];