export const SAMPLE_POSTS = [
  {
    id: 1,
    title: "Introducing the new Reddit clone built with React and Tailwind",
    author: "reactdev",
    content: "Check out this modern and responsive Reddit clone implementation using React and Tailwind CSS. It features a clean design and smooth interactions.",
    votes: 1422,
    comments: 284,
    timeAgo: "5 hours ago",
    subreddit: "webdev",
    type: "text"
  },
  {
    id: 2,
    title: "Stunning sunset captured in Norway",
    author: "naturephotographer",
    content: "",
    imageUrl: "https://images.unsplash.com/photo-1520466809213-7b9a56adcd45?auto=format&fit=crop&q=80",
    votes: 2891,
    comments: 156,
    timeAgo: "8 hours ago",
    subreddit: "pics",
    type: "image"
  },
  {
    id: 3,
    title: "Amazing street art found in Melbourne",
    author: "artlover",
    content: "",
    imageUrl: "https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?auto=format&fit=crop&q=80",
    votes: 1756,
    comments: 89,
    timeAgo: "12 hours ago",
    subreddit: "art",
    type: "image"
  },
  {
    id: 4,
    title: "This is what happens when AI generates art",
    author: "aiartist",
    content: "",
    imageUrl: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?auto=format&fit=crop&q=80",
    votes: 3421,
    comments: 445,
    timeAgo: "1 day ago",
    subreddit: "artificial",
    type: "image"
  },
  {
    id: 5,
    title: "Check out this mesmerizing timelapse of Tokyo",
    author: "videomaster",
    content: "",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-aerial-view-of-city-traffic-at-night-11-large.mp4",
    votes: 892,
    comments: 67,
    timeAgo: "2 hours ago",
    subreddit: "videos",
    type: "video"
  },
  {
    id: 6,
    title: "The science behind perfect coffee",
    author: "coffeegeek",
    content: "A deep dive into the chemistry and physics of brewing the perfect cup of coffee, including water temperature, grind size, and extraction time.",
    votes: 1205,
    comments: 198,
    timeAgo: "6 hours ago",
    subreddit: "science",
    type: "text"
  }
];