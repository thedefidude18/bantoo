import React from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { useMessageStore } from '../store/messageStore';
import { formatDistanceToNow } from '../utils/dateUtils';
import UserAvatar from '../components/User/UserAvatar';

export default function MessagesPage() {
  const { user } = useAuth0();
  const { messages, markAsRead } = useMessageStore();

  const userMessages = messages.filter(
    (msg) => msg.senderId === user?.sub || msg.receiverId === user?.sub
  );

  return (
    <div className="flex-1 max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <div className="p-4 border-b dark:border-gray-700">
          <h1 className="text-2xl font-bold">Messages</h1>
        </div>

        <div className="divide-y dark:divide-gray-700">
          {userMessages.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No messages yet
            </div>
          ) : (
            userMessages.map((message) => (
              <div
                key={message.id}
                className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer ${
                  !message.read ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
                onClick={() => !message.read && markAsRead(message.id)}
              >
                <div className="flex items-start space-x-3">
                  <UserAvatar
                    username={message.senderId === user?.sub ? 'you' : message.senderId}
                    size="md"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">
                        {message.senderId === user?.sub ? 'You' : message.senderId}
                      </p>
                      <span className="text-xs text-gray-500">
                        {formatDistanceToNow(message.timestamp)}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                      {message.content}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}