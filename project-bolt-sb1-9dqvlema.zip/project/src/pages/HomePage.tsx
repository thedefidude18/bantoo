import React, { useState } from 'react';
import { Filter } from 'lucide-react';
import CreatePostButton from '../components/CreatePost/CreatePostButton';
import CreatePostModal from '../components/CreatePost/CreatePostModal';
import Post from '../components/Post/Post';
import { SAMPLE_POSTS } from '../data/samplePosts';

export default function HomePage() {
  const [isCreatePostModalOpen, setCreatePostModalOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'hot' | 'new' | 'top' | 'rising'>('hot');

  const filters = [
    { label: 'Hot', value: 'hot' },
    { label: 'New', value: 'new' },
    { label: 'Top', value: 'top' },
    { label: 'Rising', value: 'rising' },
  ];

  return (
    <div className="flex-1 space-y-4">
      <CreatePostButton onClick={() => setCreatePostModalOpen(true)} />
      
      <div className="bg-white rounded-md p-2 flex items-center space-x-2">
        <Filter className="w-5 h-5 text-gray-400" />
        {filters.map((filter) => (
          <button
            key={filter.value}
            onClick={() => setSelectedFilter(filter.value as any)}
            className={`px-4 py-1.5 rounded-full text-sm ${
              selectedFilter === filter.value
                ? 'bg-gray-100 text-gray-900'
                : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {SAMPLE_POSTS.map((post) => (
          <Post key={post.id} {...post} />
        ))}
      </div>

      <CreatePostModal 
        isOpen={isCreatePostModalOpen}
        onClose={() => setCreatePostModalOpen(false)}
      />
    </div>
  );
}