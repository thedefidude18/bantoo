import React, { useState } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { useEarningsStore } from '../store/earningsStore';
import { formatDistanceToNow } from '../utils/dateUtils';
import { Wallet, ArrowRight, CheckCircle, XCircle, Clock } from 'lucide-react';

export default function ProfilePage() {
  const { user } = useAuth0();
  const { balance, pendingWithdrawals, requestWithdrawal } = useEarningsStore();
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const handleWithdraw = () => {
    const amount = Number(withdrawAmount);
    if (amount > 0 && amount <= balance) {
      requestWithdrawal(amount);
      setWithdrawAmount('');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-500" />;
    }
  };

  return (
    <div className="flex-1 max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        {/* Profile Header */}
        <div className="p-6 border-b dark:border-gray-700">
          <div className="flex items-center space-x-4">
            <img
              src={user?.picture}
              alt={user?.name}
              className="w-20 h-20 rounded-full"
            />
            <div>
              <h1 className="text-2xl font-bold">{user?.name}</h1>
              <p className="text-gray-500 dark:text-gray-400">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Earnings Section */}
        <div className="p-6 border-b dark:border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Earnings</h2>
            <div className="flex items-center space-x-2 px-4 py-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <Wallet className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span className="text-lg font-medium text-green-700 dark:text-green-300">
                {new Intl.NumberFormat('en-NG', {
                  style: 'currency',
                  currency: 'NGN',
                  minimumFractionDigits: 0,
                }).format(balance)}
              </span>
            </div>
          </div>

          {/* Withdrawal Form */}
          <div className="flex space-x-4 mb-8">
            <input
              type="number"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder="Enter amount to withdraw"
              className="flex-1 px-4 py-2 border dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700"
            />
            <button
              onClick={handleWithdraw}
              disabled={!withdrawAmount || Number(withdrawAmount) > balance}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Withdraw
            </button>
          </div>

          {/* Withdrawal History */}
          <div>
            <h3 className="text-lg font-medium mb-4">Withdrawal History</h3>
            <div className="space-y-4">
              {pendingWithdrawals.length === 0 ? (
                <p className="text-gray-500 dark:text-gray-400">
                  No withdrawal history yet
                </p>
              ) : (
                pendingWithdrawals.map((withdrawal) => (
                  <div
                    key={withdrawal.id}
                    className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      {getStatusIcon(withdrawal.status)}
                      <div>
                        <p className="font-medium">
                          {new Intl.NumberFormat('en-NG', {
                            style: 'currency',
                            currency: 'NGN',
                            minimumFractionDigits: 0,
                          }).format(withdrawal.amount)}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {formatDistanceToNow(withdrawal.timestamp)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center text-sm">
                      <span
                        className={`px-3 py-1 rounded-full ${
                          withdrawal.status === 'completed'
                            ? 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-300'
                            : withdrawal.status === 'failed'
                            ? 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-300'
                            : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-300'
                        }`}
                      >
                        {withdrawal.status.charAt(0).toUpperCase() + withdrawal.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}