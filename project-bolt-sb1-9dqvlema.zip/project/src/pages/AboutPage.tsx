import React from 'react';
import { Info, Github, Code, Coffee, Heart, Users, Globe, Zap } from 'lucide-react';

const FEATURES = [
  {
    icon: Users,
    title: 'Community First',
    description: 'Built for meaningful discussions and content sharing among like-minded individuals.'
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Optimized performance with React and modern web technologies.'
  },
  {
    icon: Globe,
    title: 'Always Available',
    description: 'Access your favorite communities anytime, anywhere, on any device.'
  },
  {
    icon: Heart,
    title: 'Open Source',
    description: 'Built with love by the community, for the community.'
  }
];

const TECH_STACK = [
  { name: 'React', description: 'UI Library' },
  { name: 'TypeScript', description: 'Type Safety' },
  { name: 'Tailwind CSS', description: 'Styling' },
  { name: 'Vite', description: 'Build Tool' }
];

export default function AboutPage() {
  return (
    <div className="flex-1 max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="flex items-center space-x-3 mb-8">
          <Info className="w-8 h-8 text-blue-500" />
          <h1 className="text-3xl font-bold">About Reddit Clone</h1>
        </div>

        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600 text-lg leading-relaxed mb-12">
            Welcome to our Reddit Clone, a modern web application built with the latest
            technologies and best practices in web development. Our goal is to provide
            a familiar yet enhanced experience for community engagement and content sharing.
          </p>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {FEATURES.map((feature) => (
              <div
                key={feature.title}
                className="p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <feature.icon className="w-8 h-8 text-blue-500 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>

          <h2 className="text-2xl font-bold mb-6 flex items-center">
            <Code className="w-6 h-6 text-purple-500 mr-2" />
            Technology Stack
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {TECH_STACK.map((tech) => (
              <div
                key={tech.name}
                className="text-center p-4 bg-gray-50 rounded-lg"
              >
                <h4 className="font-semibold text-gray-900">{tech.name}</h4>
                <p className="text-sm text-gray-500">{tech.description}</p>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center space-x-6 text-gray-500">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center hover:text-gray-900"
            >
              <Github className="w-5 h-5 mr-2" />
              GitHub
            </a>
            <a
              href="#"
              className="flex items-center hover:text-gray-900"
            >
              <Coffee className="w-5 h-5 mr-2" />
              Buy us a coffee
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}