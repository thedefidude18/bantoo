import React, { useState } from 'react';
import { Trophy, Flame, ThumbsUp, Calendar, Search } from 'lucide-react';

const TIME_FILTERS = ['Today', 'This Week', 'This Month', 'All Time'];
const CATEGORY_FILTERS = ['Karma', 'Posts', 'Comments', 'Awards'];

const TOP_USERS = [
  { username: 'techmaster', karma: 125890, posts: 342, awards: 89, streak: 145 },
  { username: 'codewizard', karma: 98760, posts: 256, awards: 67, streak: 89 },
  { username: 'webdev_pro', karma: 87654, posts: 198, awards: 45, streak: 67 },
  { username: 'reactninja', karma: 76543, posts: 167, awards: 34, streak: 56 },
  { username: 'cssartist', karma: 65432, posts: 145, awards: 23, streak: 34 },
  { username: 'designmaster', karma: 54321, posts: 123, awards: 21, streak: 23 },
  { username: 'uideveloper', karma: 43210, posts: 98, awards: 18, streak: 12 },
  { username: 'frontendpro', karma: 32109, posts: 76, awards: 15, streak: 8 },
];

export default function LeaderboardPage() {
  const [timeFilter, setTimeFilter] = useState('This Week');
  const [categoryFilter, setCategoryFilter] = useState('Karma');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredUsers = TOP_USERS.filter(user => 
    user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Trophy className="w-6 h-6 text-yellow-500" />
            <h1 className="text-2xl font-bold">Community Leaderboard</h1>
          </div>
          <div className="relative">
            <input
              type="text"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border rounded-full bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
          </div>
        </div>

        <div className="flex flex-wrap gap-4 mb-6">
          <div className="flex items-center space-x-2 bg-gray-50 rounded-lg p-2">
            <Calendar className="w-4 h-4 text-gray-500" />
            {TIME_FILTERS.map((filter) => (
              <button
                key={filter}
                onClick={() => setTimeFilter(filter)}
                className={`px-3 py-1 rounded-full text-sm ${
                  timeFilter === filter
                    ? 'bg-white shadow text-blue-600'
                    : 'text-gray-600 hover:bg-white hover:shadow'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className="flex items-center space-x-2 bg-gray-50 rounded-lg p-2">
            <Flame className="w-4 h-4 text-gray-500" />
            {CATEGORY_FILTERS.map((filter) => (
              <button
                key={filter}
                onClick={() => setCategoryFilter(filter)}
                className={`px-3 py-1 rounded-full text-sm ${
                  categoryFilter === filter
                    ? 'bg-white shadow text-blue-600'
                    : 'text-gray-600 hover:bg-white hover:shadow'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {filteredUsers.map((user, index) => (
            <div
              key={user.username}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center space-x-4">
                <div className={`text-2xl font-bold ${
                  index === 0 ? 'text-yellow-500' :
                  index === 1 ? 'text-gray-400' :
                  index === 2 ? 'text-amber-600' :
                  'text-gray-400'
                }`}>
                  #{index + 1}
                </div>
                <div>
                  <h3 className="font-medium">u/{user.username}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                    <span className="flex items-center">
                      <Flame className="w-4 h-4 mr-1 text-orange-500" />
                      {user.karma.toLocaleString()} karma
                    </span>
                    <span className="flex items-center">
                      <ThumbsUp className="w-4 h-4 mr-1 text-blue-500" />
                      {user.awards} awards
                    </span>
                    <span className="text-green-500">
                      {user.streak} day streak 🔥
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-500">
                {user.posts} posts
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}