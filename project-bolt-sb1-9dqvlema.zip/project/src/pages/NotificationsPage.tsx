import React from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { useNotificationStore } from '../store/notificationStore';
import { formatDistanceToNow } from '../utils/dateUtils';
import { Bell, Heart, MessageSquare, AtSign, UserPlus } from 'lucide-react';

const NotificationIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'like':
      return <Heart className="w-5 h-5 text-red-500" />;
    case 'comment':
      return <MessageSquare className="w-5 h-5 text-blue-500" />;
    case 'mention':
      return <AtSign className="w-5 h-5 text-purple-500" />;
    case 'follow':
      return <UserPlus className="w-5 h-5 text-green-500" />;
    default:
      return <Bell className="w-5 h-5 text-gray-500" />;
  }
};

export default function NotificationsPage() {
  const { user } = useAuth0();
  const { notifications, markAsRead, markAllAsRead } = useNotificationStore();

  const userNotifications = notifications.filter(
    (notif) => notif.userId === user?.sub
  );

  return (
    <div className="flex-1 max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <div className="p-4 border-b dark:border-gray-700 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Notifications</h1>
          {userNotifications.length > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-sm text-blue-500 hover:text-blue-600"
            >
              Mark all as read
            </button>
          )}
        </div>

        <div className="divide-y dark:divide-gray-700">
          {userNotifications.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No notifications yet
            </div>
          ) : (
            userNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer ${
                  !notification.read ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
                onClick={() => !notification.read && markAsRead(notification.id)}
              >
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                    <NotificationIcon type={notification.type} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">
                        {notification.content}
                      </p>
                      <span className="text-xs text-gray-500">
                        {formatDistanceToNow(notification.timestamp)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}