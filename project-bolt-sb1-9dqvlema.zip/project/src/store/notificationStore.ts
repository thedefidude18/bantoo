import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Notification {
  id: number;
  userId: string;
  type: 'like' | 'comment' | 'mention' | 'follow';
  content: string;
  timestamp: number;
  read: boolean;
}

interface NotificationStore {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (notificationId: number) => void;
  markAllAsRead: () => void;
}

export const useNotificationStore = create<NotificationStore>()(
  persist(
    (set) => ({
      notifications: [],
      unreadCount: 0,
      addNotification: (newNotification) =>
        set((state) => ({
          notifications: [
            {
              ...newNotification,
              id: Date.now(),
              timestamp: Date.now(),
              read: false,
            },
            ...state.notifications,
          ],
          unreadCount: state.unreadCount + 1,
        })),
      markAsRead: (notificationId) =>
        set((state) => ({
          notifications: state.notifications.map((notif) =>
            notif.id === notificationId ? { ...notif, read: true } : notif
          ),
          unreadCount: state.unreadCount - 1,
        })),
      markAllAsRead: () =>
        set((state) => ({
          notifications: state.notifications.map((notif) => ({ ...notif, read: true })),
          unreadCount: 0,
        })),
    }),
    {
      name: 'notification-storage',
    }
  )
);