import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface EarningsStore {
  balance: number;
  pendingWithdrawals: {
    id: string;
    amount: number;
    status: 'pending' | 'completed' | 'failed';
    timestamp: number;
  }[];
  addEarnings: (amount: number) => void;
  requestWithdrawal: (amount: number) => string;
  updateWithdrawalStatus: (id: string, status: 'completed' | 'failed') => void;
}

const NAIRA_PER_UPVOTE = 100; // ₦100 per upvote

export const useEarningsStore = create<EarningsStore>()(
  persist(
    (set) => ({
      balance: 0,
      pendingWithdrawals: [],
      addEarnings: (upvotes) =>
        set((state) => ({
          balance: state.balance + (upvotes * NAIRA_PER_UPVOTE),
        })),
      requestWithdrawal: (amount) =>
        set((state) => {
          if (amount > state.balance) return state.pendingWithdrawals[0]?.id || '';
          
          const withdrawalId = Date.now().toString();
          return {
            balance: state.balance - amount,
            pendingWithdrawals: [
              ...state.pendingWithdrawals,
              {
                id: withdrawalId,
                amount,
                status: 'pending',
                timestamp: Date.now(),
              },
            ],
          };
        }),
      updateWithdrawalStatus: (id, status) =>
        set((state) => ({
          pendingWithdrawals: state.pendingWithdrawals.map((w) =>
            w.id === id ? { ...w, status } : w
          ),
        })),
    }),
    {
      name: 'earnings-storage',
    }
  )
);