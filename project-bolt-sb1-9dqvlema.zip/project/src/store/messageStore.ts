import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Message {
  id: number;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: number;
  read: boolean;
}

interface MessageStore {
  messages: Message[];
  unreadCount: number;
  addMessage: (message: Omit<Message, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (messageId: number) => void;
  markAllAsRead: () => void;
}

export const useMessageStore = create<MessageStore>()(
  persist(
    (set) => ({
      messages: [],
      unreadCount: 0,
      addMessage: (newMessage) =>
        set((state) => ({
          messages: [
            {
              ...newMessage,
              id: Date.now(),
              timestamp: Date.now(),
              read: false,
            },
            ...state.messages,
          ],
          unreadCount: state.unreadCount + 1,
        })),
      markAsRead: (messageId) =>
        set((state) => ({
          messages: state.messages.map((msg) =>
            msg.id === messageId ? { ...msg, read: true } : msg
          ),
          unreadCount: state.unreadCount - 1,
        })),
      markAllAsRead: () =>
        set((state) => ({
          messages: state.messages.map((msg) => ({ ...msg, read: true })),
          unreadCount: 0,
        })),
    }),
    {
      name: 'message-storage',
    }
  )
);