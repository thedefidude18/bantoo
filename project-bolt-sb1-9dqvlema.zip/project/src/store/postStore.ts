import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Post } from '../types/post';
import { SAMPLE_POSTS } from '../data/samplePosts';

interface PostStore {
  posts: Post[];
  addPost: (post: Omit<Post, 'id' | 'votes' | 'comments' | 'timeAgo'>) => void;
  updatePost: (id: number, updates: Partial<Post>) => void;
  deletePost: (id: number) => void;
  votePost: (id: number, direction: 'up' | 'down') => void;
}

export const usePostStore = create<PostStore>()(
  persist(
    (set) => ({
      posts: SAMPLE_POSTS,
      addPost: (newPost) =>
        set((state) => ({
          posts: [
            {
              ...newPost,
              id: Date.now(),
              votes: 0,
              comments: 0,
              timeAgo: 'just now',
            },
            ...state.posts,
          ],
        })),
      updatePost: (id, updates) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === id ? { ...post, ...updates } : post
          ),
        })),
      deletePost: (id) =>
        set((state) => ({
          posts: state.posts.filter((post) => post.id !== id),
        })),
      votePost: (id, direction) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === id
              ? {
                  ...post,
                  votes:
                    post.votes + (direction === 'up' ? 1 : -1),
                }
              : post
          ),
        })),
    }),
    {
      name: 'post-storage',
    }
  )
);