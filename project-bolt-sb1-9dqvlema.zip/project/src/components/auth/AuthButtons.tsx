import React from 'react';
import { LogIn } from 'lucide-react';
import { usePrivy } from '@privy-io/react-auth';
import { useThemeStore } from '../../store/themeStore';

export default function AuthButtons() {
  const { login, logout, authenticated, user } = usePrivy();
  const { theme } = useThemeStore();

  if (authenticated && user) {
    return (
      <div className="flex items-center space-x-4">
        <img
          src={user.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${user.email?.address}`}
          alt={user.email?.address || 'User avatar'}
          className="w-8 h-8 rounded-full bg-gray-200"
        />
        <button
          onClick={logout}
          className="text-sm text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
        >
          Log out
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => login({ theme: theme === 'dark' ? 'dark' : 'light' })}
      className="flex items-center space-x-2 px-4 py-2 rounded-full bg-orange-500 hover:bg-orange-600 text-white transition-colors"
    >
      <LogIn className="w-4 h-4" />
      <span>Log In</span>
    </button>
  );
}