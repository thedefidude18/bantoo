import React from 'react';
import { PrivyProvider } from '@privy-io/react-auth';
import { useThemeStore } from '../../store/themeStore';

interface AuthProviderProps {
  children: React.ReactNode;
}

export default function AuthProvider({ children }: AuthProviderProps) {
  const { theme } = useThemeStore();
  
  return (
    <PrivyProvider
      appId={import.meta.env.VITE_PRIVY_APP_ID}
      config={{
        loginMethods: ['email', 'google', 'twitter', 'facebook'],
        appearance: {
          theme: theme === 'dark' ? 'dark' : 'light',
          accentColor: '#FF4500',
          showWalletLoginFirst: false,
          defaultWalletLoginFirst: false,
          logo: 'https://www.redditstatic.com/desktop2x/img/favicon/android-icon-192x192.png',
          showWeb3Features: false
        },
        onboardingConfig: {
          emailVerificationScreen: {
            heading: "Welcome to Reddit Clone",
            subheading: "Verify your email to continue"
          }
        }
      }}
    >
      {children}
    </PrivyProvider>
  );
}