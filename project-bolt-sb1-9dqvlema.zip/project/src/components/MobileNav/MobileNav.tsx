import React from 'react';
import { Home, BarChart2, Trophy, Info, Menu, X } from 'lucide-react';
import { useLocation } from 'react-router-dom';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

const NAV_ITEMS = [
  { icon: Home, label: 'Home', path: '/' },
  { icon: BarChart2, label: 'Popular', path: '/popular' },
  { icon: Trophy, label: 'Leaderboard', path: '/leaderboard' },
  { icon: Info, label: 'About', path: '/about' },
];

export default function MobileNav({ isOpen, onClose }: MobileNavProps) {
  const location = useLocation();

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed inset-y-0 left-0 w-64 bg-white transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-200 ease-in-out z-50 md:hidden`}
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <span className="text-orange-500 font-bold text-2xl">reddit</span>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="space-y-2">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.label}
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg ${
                  location.pathname === item.path
                    ? 'bg-gray-100 text-orange-500'
                    : 'hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
}