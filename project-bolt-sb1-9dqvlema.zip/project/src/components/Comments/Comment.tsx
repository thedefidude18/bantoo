import React, { useState } from 'react';
import { MessageSquare, MoreHorizontal } from 'lucide-react';
import UserAvatar from '../User/UserAvatar';
import VoteButtons from '../Post/VoteButtons';
import CommentForm from './CommentForm';
import type { Comment as CommentType } from '../../types/comment';

interface CommentProps {
  comment: CommentType;
  onReply: (content: string) => void;
}

export default function Comment({ comment, onReply }: CommentProps) {
  const [isReplying, setIsReplying] = useState(false);
  const [showReplies, setShowReplies] = useState(true);

  const handleReply = (content: string) => {
    onReply(content);
    setIsReplying(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex space-x-3">
        <UserAvatar username={comment.author} size="sm" />
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <span className="font-medium">u/{comment.author}</span>
            <span className="text-xs text-gray-500">{comment.timeAgo}</span>
          </div>
          <p className="mt-1 text-gray-800">{comment.content}</p>
          
          <div className="flex items-center space-x-4 mt-2">
            <VoteButtons votes={comment.votes} />
            <button
              onClick={() => setIsReplying(!isReplying)}
              className="flex items-center space-x-1 text-gray-500 hover:bg-gray-100 rounded-md px-2 py-1"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="text-xs">Reply</span>
            </button>
            <button className="text-gray-500 hover:bg-gray-100 rounded-full p-1">
              <MoreHorizontal className="w-4 h-4" />
            </button>
          </div>

          {isReplying && (
            <div className="mt-3">
              <CommentForm
                onSubmit={handleReply}
                placeholder="What are your thoughts on this comment?"
              />
            </div>
          )}
        </div>
      </div>

      {comment.replies.length > 0 && (
        <div className="ml-8 pl-4 border-l-2 border-gray-200">
          {comment.replies.map((reply) => (
            <Comment key={reply.id} comment={reply} onReply={onReply} />
          ))}
        </div>
      )}
    </div>
  );
}