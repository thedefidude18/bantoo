import React from 'react';
import Comment from './Comment';
import CommentForm from './CommentForm';
import type { Comment as CommentType } from '../../types/comment';

interface CommentSectionProps {
  comments: CommentType[];
  onAddComment: (content: string) => void;
  onReply: (commentId: number, content: string) => void;
}

export default function CommentSection({ comments, onAddComment, onReply }: CommentSectionProps) {
  return (
    <div className="space-y-6">
      <div className="mb-6">
        <CommentForm onSubmit={onAddComment} />
      </div>

      <div className="space-y-6">
        {comments.map((comment) => (
          <Comment
            key={comment.id}
            comment={comment}
            onReply={(content) => onReply(comment.id, content)}
          />
        ))}
      </div>
    </div>
  );
}