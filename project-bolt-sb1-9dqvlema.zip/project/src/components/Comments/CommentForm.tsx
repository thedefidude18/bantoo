import React, { useState } from 'react';
import UserAvatar from '../User/UserAvatar';

interface CommentFormProps {
  onSubmit: (content: string) => void;
  placeholder?: string;
}

export default function CommentForm({ onSubmit, placeholder = "What are your thoughts?" }: CommentFormProps) {
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onSubmit(content);
      setContent('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex space-x-4">
      <UserAvatar username="you" size="sm" />
      <div className="flex-1">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={placeholder}
          className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          rows={4}
        />
        <div className="flex justify-end mt-2">
          <button
            type="submit"
            disabled={!content.trim()}
            className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 
              disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Comment
          </button>
        </div>
      </div>
    </form>
  );
}