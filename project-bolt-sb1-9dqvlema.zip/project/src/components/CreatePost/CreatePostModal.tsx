import React, { useState } from 'react';
import { X, Image, Link, Type } from 'lucide-react';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreatePostModal({ isOpen, onClose }: CreatePostModalProps) {
  const [postType, setPostType] = useState<'text' | 'image' | 'link'>('text');
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Create a post</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="flex space-x-4 mb-4">
            <button
              onClick={() => setPostType('text')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full ${
                postType === 'text' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'
              }`}
            >
              <Type className="w-5 h-5" />
              <span>Text</span>
            </button>
            <button
              onClick={() => setPostType('image')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full ${
                postType === 'image' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'
              }`}
            >
              <Image className="w-5 h-5" />
              <span>Image</span>
            </button>
            <button
              onClick={() => setPostType('link')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full ${
                postType === 'link' ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'
              }`}
            >
              <Link className="w-5 h-5" />
              <span>Link</span>
            </button>
          </div>

          <input
            type="text"
            placeholder="Title"
            className="w-full p-2 border rounded-md mb-4"
          />

          {postType === 'text' && (
            <textarea
              placeholder="Text (optional)"
              className="w-full p-2 border rounded-md h-32 mb-4"
            />
          )}

          {postType === 'image' && (
            <div className="border-2 border-dashed rounded-md p-8 text-center mb-4">
              <Image className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-gray-500">Drag and drop images or click to upload</p>
            </div>
          )}

          {postType === 'link' && (
            <input
              type="url"
              placeholder="Url"
              className="w-full p-2 border rounded-md mb-4"
            />
          )}

          <div className="flex justify-end space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-full hover:bg-gray-100"
            >
              Cancel
            </button>
            <button className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600">
              Post
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}