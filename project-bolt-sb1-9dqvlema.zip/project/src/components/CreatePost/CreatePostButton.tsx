import React from 'react';
import { PenSquare } from 'lucide-react';

interface CreatePostButtonProps {
  onClick: () => void;
}

export default function CreatePostButton({ onClick }: CreatePostButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-white border border-gray-200 rounded-md p-3 flex items-center space-x-3 hover:border-blue-500 cursor-pointer mb-4"
    >
      <PenSquare className="w-5 h-5 text-gray-400" />
      <span className="text-gray-500">Create Post</span>
    </button>
  );
}