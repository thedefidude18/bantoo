import React from 'react';
import { Search } from 'lucide-react';

export default function SearchBar() {
  return (
    <div className="flex-1 max-w-2xl mx-4">
      <div className="relative">
        <input
          type="text"
          placeholder="Search Reddit"
          className="w-full bg-gray-100 border border-gray-200 rounded-full py-1.5 pl-10 pr-4 focus:outline-none focus:border-blue-500"
        />
        <Search className="absolute left-3 top-1.5 w-5 h-5 text-gray-400" />
      </div>
    </div>
  );
}