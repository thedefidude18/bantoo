import React from 'react';
import { Wallet } from 'lucide-react';
import { useEarningsStore } from '../../store/earningsStore';

export default function UserBalance() {
  const { balance } = useEarningsStore();

  const formattedBalance = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(balance);

  return (
    <div className="flex items-center space-x-2 px-3 py-1.5 bg-green-50 dark:bg-green-900/20 rounded-full">
      <Wallet className="w-4 h-4 text-green-600 dark:text-green-400" />
      <span className="text-sm font-medium text-green-700 dark:text-green-300">
        {formattedBalance}
      </span>
    </div>
  );
}