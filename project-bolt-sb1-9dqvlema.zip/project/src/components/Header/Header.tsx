import React from 'react';
import Logo from './Logo';
import SearchBar from './SearchBar';
import UserActions from './UserActions';

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-2">
        <Logo onMenuClick={onMenuClick} />
        <SearchBar />
        <UserActions />
      </div>
    </header>
  );
}