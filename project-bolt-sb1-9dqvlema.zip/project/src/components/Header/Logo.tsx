import React from 'react';
import { Menu } from 'lucide-react';

interface LogoProps {
  onMenuClick: () => void;
}

export default function Logo({ onMenuClick }: LogoProps) {
  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2">
        {/* Mobile menu button */}
        <button 
          onClick={onMenuClick}
          className="md:hidden p-2 hover:bg-gray-100 rounded-full"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="text-orange-500 font-bold text-2xl">reddit</div>
      </div>
      <button className="hidden md:flex items-center space-x-1 hover:bg-gray-100 px-3 py-1 rounded-md">
        <Menu className="w-5 h-5" />
      </button>
    </div>
  );
}