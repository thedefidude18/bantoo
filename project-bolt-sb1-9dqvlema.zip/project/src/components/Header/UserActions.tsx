import React from 'react';
import { Link } from 'react-router-dom';
import { Bell, MessageSquare } from 'lucide-react';
import { useAuth0 } from '@auth0/auth0-react';
import { useMessageStore } from '../../store/messageStore';
import { useNotificationStore } from '../../store/notificationStore';
import ThemeToggle from '../ThemeToggle';
import AuthButtons from '../auth/AuthButtons';
import UserBalance from './UserBalance';

export default function UserActions() {
  const { isAuthenticated } = useAuth0();
  const { unreadCount: unreadMessages } = useMessageStore();
  const { unreadCount: unreadNotifications } = useNotificationStore();

  return (
    <div className="flex items-center space-x-4">
      {isAuthenticated && <UserBalance />}
      <Link
        to="/notifications"
        className="hidden md:flex items-center space-x-1 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-full relative"
      >
        <Bell className="w-5 h-5" />
        {unreadNotifications > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {unreadNotifications}
          </span>
        )}
      </Link>
      <Link
        to="/messages"
        className="hidden md:flex items-center space-x-1 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-full relative"
      >
        <MessageSquare className="w-5 h-5" />
        {unreadMessages > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {unreadMessages}
          </span>
        )}
      </Link>
      <ThemeToggle />
      <AuthButtons />
    </div>
  );
}