import React from 'react';
import { Search, Bell, MessageSquare, User, Menu } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-2">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="text-orange-500 font-bold text-2xl">reddit</div>
          </div>
          <button className="hidden md:flex items-center space-x-1 hover:bg-gray-100 px-3 py-1 rounded-md">
            <Menu className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 max-w-2xl mx-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search Reddit"
              className="w-full bg-gray-100 border border-gray-200 rounded-full py-1.5 pl-10 pr-4 focus:outline-none focus:border-blue-500"
            />
            <Search className="absolute left-3 top-1.5 w-5 h-5 text-gray-400" />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button className="hidden md:flex items-center space-x-1 hover:bg-gray-100 p-2 rounded-full">
            <Bell className="w-5 h-5" />
          </button>
          <button className="hidden md:flex items-center space-x-1 hover:bg-gray-100 p-2 rounded-full">
            <MessageSquare className="w-5 h-5" />
          </button>
          <button className="flex items-center space-x-1 hover:bg-gray-100 p-2 rounded-full">
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}