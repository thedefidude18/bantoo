import React from 'react';

interface CommunityItemProps {
  name: string;
}

export default function CommunityItem({ name }: CommunityItemProps) {
  return (
    <button className="text-sm hover:bg-gray-100 w-full text-left px-2 py-1.5 rounded-md">
      {name}
    </button>
  );
}