import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavigationItemProps {
  icon: LucideIcon;
  label: string;
}

export default function NavigationItem({ icon: Icon, label }: NavigationItemProps) {
  return (
    <button className="flex items-center space-x-2 hover:bg-gray-100 w-full px-2 py-1.5 rounded-md">
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </button>
  );
}