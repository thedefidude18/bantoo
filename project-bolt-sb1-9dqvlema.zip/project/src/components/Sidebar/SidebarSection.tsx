import React, { ReactNode } from 'react';

interface SidebarSectionProps {
  title: string;
  children: ReactNode;
  action?: ReactNode;
}

export default function SidebarSection({ title, children, action }: SidebarSectionProps) {
  return (
    <div className="bg-white rounded-md shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-medium">{title}</h2>
        {action}
      </div>
      {children}
    </div>
  );
}