import React from 'react';
import { Home, BarChart2, Star, Plus } from 'lucide-react';
import NavigationItem from './NavigationItem';
import CommunityItem from './CommunityItem';
import SidebarSection from './SidebarSection';

const COMMUNITIES = [
  'r/programming',
  'r/javascript',
  'r/reactjs',
  'r/webdev',
  'r/coding'
];

const NAVIGATION_ITEMS = [
  { icon: Home, label: 'Home' },
  { icon: BarChart2, label: 'Popular' },
  { icon: Star, label: 'All' }
];

export default function Sidebar() {
  const addCommunityButton = (
    <button className="text-blue-500 hover:bg-blue-50 p-1 rounded-md">
      <Plus className="w-5 h-5" />
    </button>
  );

  return (
    <div className="hidden md:block w-64 p-4 space-y-4">
      <SidebarSection title="Popular Communities">
        <nav className="space-y-2">
          {NAVIGATION_ITEMS.map((item) => (
            <NavigationItem
              key={item.label}
              icon={item.icon}
              label={item.label}
            />
          ))}
        </nav>
      </SidebarSection>

      <SidebarSection title="Communities" action={addCommunityButton}>
        <div className="space-y-2">
          {COMMUNITIES.map((community) => (
            <CommunityItem key={community} name={community} />
          ))}
        </div>
      </SidebarSection>
    </div>
  );
}