import React from 'react';
import { Home, Trending, Star, Plus } from 'lucide-react';

export default function Sidebar() {
  const communities = [
    'r/programming',
    'r/javascript',
    'r/reactjs',
    'r/webdev',
    'r/coding'
  ];

  return (
    <div className="hidden md:block w-64 p-4 space-y-4">
      <div className="bg-white rounded-md shadow-sm p-4">
        <h2 className="font-medium mb-4">Popular Communities</h2>
        <nav className="space-y-2">
          <button className="flex items-center space-x-2 hover:bg-gray-100 w-full px-2 py-1.5 rounded-md">
            <Home className="w-5 h-5" />
            <span>Home</span>
          </button>
          <button className="flex items-center space-x-2 hover:bg-gray-100 w-full px-2 py-1.5 rounded-md">
            <Trending className="w-5 h-5" />
            <span>Popular</span>
          </button>
          <button className="flex items-center space-x-2 hover:bg-gray-100 w-full px-2 py-1.5 rounded-md">
            <Star className="w-5 h-5" />
            <span>All</span>
          </button>
        </nav>
      </div>

      <div className="bg-white rounded-md shadow-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-medium">Communities</h2>
          <button className="text-blue-500 hover:bg-blue-50 p-1 rounded-md">
            <Plus className="w-5 h-5" />
          </button>
        </div>
        <div className="space-y-2">
          {communities.map((community) => (
            <button
              key={community}
              className="text-sm hover:bg-gray-100 w-full text-left px-2 py-1.5 rounded-md"
            >
              {community}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}