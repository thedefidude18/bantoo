import React from 'react';
import { MessageSquare, Share2, BookmarkPlus } from 'lucide-react';
import VoteButtons from './VoteButtons';

interface PostActionsProps {
  votes: number;
  comments: number;
  onShare?: () => void;
  onSave?: () => void;
  onComment?: () => void;
}

export default function PostActions({ votes, comments, onShare, onSave, onComment }: PostActionsProps) {
  return (
    <div className="flex items-center space-x-4 text-gray-500">
      <VoteButtons votes={votes} />
      
      <button 
        onClick={onComment}
        className="flex items-center space-x-1 hover:bg-gray-100 rounded-md px-2 py-1"
      >
        <MessageSquare className="w-4 h-4" />
        <span className="text-xs">{comments} Comments</span>
      </button>
      
      <button 
        onClick={onShare}
        className="flex items-center space-x-1 hover:bg-gray-100 rounded-md px-2 py-1"
      >
        <Share2 className="w-4 h-4" />
        <span className="text-xs">Share</span>
      </button>
      
      <button 
        onClick={onSave}
        className="flex items-center space-x-1 hover:bg-gray-100 rounded-md px-2 py-1"
      >
        <BookmarkPlus className="w-4 h-4" />
        <span className="text-xs">Save</span>
      </button>
    </div>
  );
}