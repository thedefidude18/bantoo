import React from 'react';

interface PostMetadataProps {
  subreddit: string;
  author: string;
  timeAgo: string;
}

export default function PostMetadata({ subreddit, author, timeAgo }: PostMetadataProps) {
  return (
    <div className="flex items-center text-xs text-gray-500 mb-2">
      <span className="font-medium text-black">r/{subreddit}</span>
      <span className="mx-1">•</span>
      <span>Posted by u/{author}</span>
      <span className="mx-1">•</span>
      <span>{timeAgo}</span>
    </div>
  );
}