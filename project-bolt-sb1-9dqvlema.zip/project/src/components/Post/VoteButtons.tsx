import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { useVote } from '../../hooks/useVote';

interface VoteButtonsProps {
  votes: number;
}

export default function VoteButtons({ votes: initialVotes }: VoteButtonsProps) {
  const { votes, userVote, handleVote } = useVote(initialVotes);

  return (
    <div className="flex items-center space-x-1">
      <button
        onClick={() => handleVote('up')}
        className="hover:bg-gray-100 rounded-md p-1"
      >
        <ArrowUp className={`w-4 h-4 ${
          userVote === 'up' ? 'text-orange-500' : 'text-gray-400 hover:text-orange-500'
        }`} />
      </button>
      
      <span className="text-xs font-medium mx-1">{votes}</span>
      
      <button
        onClick={() => handleVote('down')}
        className="hover:bg-gray-100 rounded-md p-1"
      >
        <ArrowDown className={`w-4 h-4 ${
          userVote === 'down' ? 'text-blue-500' : 'text-gray-400 hover:text-blue-500'
        }`} />
      </button>
    </div>
  );
}