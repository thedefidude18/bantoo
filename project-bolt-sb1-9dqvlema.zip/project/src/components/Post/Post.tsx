import React, { useState } from 'react';
import PostContent from './PostContent';
import PostMetadata from './PostMetadata';
import PostActions from './PostActions';
import CommentSection from '../Comments/CommentSection';
import { SAMPLE_COMMENTS } from '../../data/sampleComments';
import type { Post as PostType } from '../../types/post';
import type { Comment } from '../../types/comment';

interface PostProps extends PostType {}

export default function Post(props: PostProps) {
  const [comments, setComments] = useState<Comment[]>(SAMPLE_COMMENTS);
  const [showComments, setShowComments] = useState(false);
  
  const handleAddComment = (content: string) => {
    const newComment: Comment = {
      id: Date.now(),
      author: 'you',
      content,
      votes: 0,
      timeAgo: 'just now',
      replies: []
    };
    setComments([newComment, ...comments]);
  };

  const handleReply = (commentId: number, content: string) => {
    const newReply: Comment = {
      id: Date.now(),
      author: 'you',
      content,
      votes: 0,
      timeAgo: 'just now',
      replies: []
    };

    const addReply = (comments: Comment[]): Comment[] => {
      return comments.map(comment => {
        if (comment.id === commentId) {
          return {
            ...comment,
            replies: [newReply, ...comment.replies]
          };
        }
        if (comment.replies.length > 0) {
          return {
            ...comment,
            replies: addReply(comment.replies)
          };
        }
        return comment;
      });
    };

    setComments(addReply(comments));
  };

  return (
    <div className="bg-white rounded-md shadow-sm hover:border hover:border-gray-300">
      <div className="p-3">
        <PostMetadata {...props} />
        <PostContent {...props} />
        <PostActions
          {...props}
          onComment={() => setShowComments(!showComments)}
        />
        
        {showComments && (
          <div className="mt-4 pt-4 border-t">
            <CommentSection
              comments={comments}
              onAddComment={handleAddComment}
              onReply={handleReply}
            />
          </div>
        )}
      </div>
    </div>
  );
}