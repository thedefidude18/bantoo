import React from 'react';

interface PostContentProps {
  title: string;
  content?: string;
  imageUrl?: string;
  videoUrl?: string;
  type: 'text' | 'image' | 'video';
}

export default function PostContent({ title, content, imageUrl, videoUrl, type }: PostContentProps) {
  return (
    <div>
      <h2 className="text-lg font-medium mb-2">{title}</h2>
      {type === 'text' && content && (
        <p className="text-sm text-gray-800 mb-3">{content}</p>
      )}
      {type === 'image' && imageUrl && (
        <div className="mb-3">
          <img 
            src={imageUrl} 
            alt={title}
            className="rounded-md max-h-[600px] w-full object-cover"
          />
        </div>
      )}
      {type === 'video' && videoUrl && (
        <div className="mb-3">
          <video 
            controls 
            className="rounded-md w-full max-h-[600px]"
          >
            <source src={videoUrl} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
      )}
    </div>
  );
}