import { useState } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { useEarningsStore } from '../store/earningsStore';

type VoteDirection = 'up' | 'down' | null;

interface UseVoteReturn {
  votes: number;
  userVote: VoteDirection;
  handleVote: (direction: 'up' | 'down') => void;
}

export function useVote(initialVotes: number): UseVoteReturn {
  const [votes, setVotes] = useState(initialVotes);
  const [userVote, setUserVote] = useState<VoteDirection>(null);
  const { isAuthenticated } = useAuth0();
  const { addEarnings } = useEarningsStore();

  const handleVote = (direction: 'up' | 'down') => {
    if (!isAuthenticated) {
      // Handle unauthenticated user
      return;
    }

    if (userVote === direction) {
      // Remove vote
      setVotes(initialVotes);
      setUserVote(null);
      if (direction === 'up') {
        addEarnings(-1); // Remove earnings for removed upvote
      }
    } else {
      // Add or change vote
      const voteChange = direction === 'up' ? 1 : -1;
      const previousVoteChange = userVote ? (userVote === 'up' ? -1 : 1) : 0;
      setVotes(initialVotes + voteChange + previousVoteChange);
      setUserVote(direction);

      // Add earnings for upvote
      if (direction === 'up') {
        addEarnings(1);
      } else if (userVote === 'up') {
        addEarnings(-1); // Remove earnings when changing from upvote to downvote
      }
    }
  };

  return {
    votes,
    userVote,
    handleVote,
  };
}