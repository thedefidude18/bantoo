import { usePrivy } from '@privy-io/react-auth';
import { useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import type { AuthUser } from '../types/auth';

export function useAuth() {
  const { authenticated, user, ready } = usePrivy();
  const { setUser, logout: logoutStore } = useAuthStore();

  useEffect(() => {
    if (ready) {
      if (authenticated && user) {
        const authUser: AuthUser = {
          id: user.id,
          email: user.email?.address || '',
          name: user.email?.address?.split('@')[0] || 'Anonymous',
          picture: user.avatar || '',
          provider: user.linkedAccounts[0]?.type || 'email'
        };
        setUser(authUser);
      } else {
        logoutStore();
      }
    }
  }, [authenticated, user, ready, setUser, logoutStore]);

  return { isAuthenticated: authenticated, user };
}