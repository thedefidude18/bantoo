export interface User {
  id: number;
  username: string;
  avatarUrl: string;
  karma: number;
  joinDate: string;
}