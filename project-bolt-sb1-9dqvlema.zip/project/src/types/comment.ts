export interface Comment {
  id: number;
  author: string;
  content: string;
  votes: number;
  timeAgo: string;
  replies: Comment[];
}

export interface CommentVote {
  commentId: number;
  direction: 'up' | 'down' | null;
  value: number;
}