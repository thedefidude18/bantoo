export interface AuthUser {
  id: string;
  email: string;
  name: string;
  picture: string;
  provider: 'email' | 'google' | 'twitter' | 'facebook';
}

export interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  setUser: (user: AuthUser | null) => void;
  logout: () => void;
}