export interface Post {
  id: number;
  title: string;
  author: string;
  content?: string;
  imageUrl?: string;
  videoUrl?: string;
  votes: number;
  comments: number;
  timeAgo: string;
  subreddit: string;
  type: 'text' | 'image' | 'video' | 'link';
}

export type PostType = Post['type'];

export interface PostVote {
  postId: number;
  direction: 'up' | 'down' | null;
  value: number;
}